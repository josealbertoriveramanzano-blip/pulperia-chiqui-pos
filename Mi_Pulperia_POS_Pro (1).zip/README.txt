MI PULPERÍA POS PRO
Incluye ventas, formas de pago, fiado y abonos, clientes, compras/proveedores, inventario, costos y márgenes, gastos, caja y cierre, reportes y respaldo local.
Los datos se guardan localmente en el dispositivo.
Para instalar como app PWA, publica los archivos en HTTPS y abre index.html mediante esa dirección en Chrome; usa Menú > Instalar aplicación.
